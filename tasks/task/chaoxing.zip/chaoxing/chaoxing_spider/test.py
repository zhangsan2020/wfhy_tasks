def testExcept():
    try:
        str1 = 'fei'
        int1 = 5
        result = str1 / int1
    except Exception as e:
        print(e)
        print(f'error file:{e.__traceback__.tb_frame.f_globals["__file__"]}')
        print(f"error line:{e.__traceback__.tb_lineno}")


testExcept()
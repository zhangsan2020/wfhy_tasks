mongo_main_info = {
    'host': '47.93.86.81',
    'port': 27017
}
redis_main_info = {
    'host': '47.93.86.81',
    'password': 'jiamianwuke2018',
    'port': '6379'
}

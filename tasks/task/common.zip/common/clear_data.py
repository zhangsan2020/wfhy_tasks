import pandas as pd

data = pd.read_excel('./chictr_mid_data.xlsx')
print(data.head())
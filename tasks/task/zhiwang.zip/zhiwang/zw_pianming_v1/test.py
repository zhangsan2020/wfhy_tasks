
a = {'eric': 80, 'bob': 90, 'jean': 0,'a':4}
print(a.keys())
print(len(a.keys()))